package Rule;

public class JTextArea {
}
