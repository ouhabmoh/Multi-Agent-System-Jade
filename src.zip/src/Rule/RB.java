package Rule;

public interface RB {
    void init(BooleanRuleBase rb, String[] produits, int qteT, double prixTotale);
}
