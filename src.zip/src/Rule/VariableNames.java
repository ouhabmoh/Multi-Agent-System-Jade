package Rule;

public class VariableNames {
    public static final String vehicleType = "vehicleType";
    public static final String numWheels = "numWheels";
    public static final String motor = "motor";
    public static final String vehicle = "vehicle";
    public static final String bicycle = "bicycle";
    public static final String cycle = "cycle";
    public static final String tricycle = "tricycle";
    public static final String motorcycle = "motorcycle";
    public static final String automobile = "automobile";
    public static final String size = "size";
    public static final String small = "small";
    public static final String numDoors = "num_doors";
    public static final String sportsCar = "sprotsCar";
    public static final String sedan = "sedan";
    public static final String medium = "medium";
    public static final String minivan = "minivan";
    public static final String large = "large";
    public static final String sportsUtilityVehicle = "sportsUtilityVehicle";
    public static final String yes = "yes";
    public static final String no = "no";


}
