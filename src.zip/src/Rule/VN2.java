package Rule;

public class VN2 {
    public static final String usageType = "usageType";
    public static final String storage = "storage";
    public static final String size = "size";
    public static final String mark = "mark";
    public static final String price = "price";
    public static final String playingQuality = "playingQuality";
    public static final String nbGames = "nbGames";
    public static final String screen = "screen";
    public static final String yes = "yes";
    public static final String no = "no";
    public static final String small = "small";
    public static final String medium = "medium";
    public static final String large = "large";
    public static final String gaming = "gaming";
    public static final String all = "all";
    public static final String pc = "pc";
    public static final String low = "low";
    public static final String high = "high";
    public static final String few = "few";
    public static final String average = "average";
    public static final String more= "more";
    public static final String xbox = "xbox";
    public static final String ps = "ps";
    public static final String nintendo = "nintendo";
    public static final String xbox360Arcade = "xbox360Arcade";
    public static final String xbox360Slim = "xbox360Slim";
    public static final String xbox360Elite = "xbox360Elite";
    public static final String ps3 = "ps3";
    public static final String ps3Slim = "ps3Slim";
    public static final String ps3UltraSlim = "ps3UltraSLim";
    public static final String ps4 = "ps4";
    public static final String ps4Slim = "ps4Slim";
    public static final String ps4Pro = "ps4Pro";
    public static final String type = "type";
    public static final String budget = "budget";

}
