package Rule;

public class ITextArea {
}
